package com.cg.banking.test;
import static org.junit.Assert.*;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Address;
import com.cg.banking.beans.Customer;import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.BankingDAOServicesImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.CustomerNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;
import com.cg.banking.utility.BankingUtility;
public class BankingServicesTest {
	private static BankingServices bankingservices;
	@BeforeClass
	public static void setUpTestEnv(){
		bankingservices= new BankingServicesImpl();
	}
	@Before
	public void setUpMockData(){
		//BankingUtility.CUSTOMER_ID_COUNTER=111;
		//BankingUtility.ACCOUNT_NUM_COUNTER=20000;
		
		Customer customer1=new Customer("ggh788","mani", "pichii", "pichi.com", new Address(12354, "hyd", "tg"), new Address(4563, "gdk","tg"));
		customer1.setCustomerId(BankingUtility.CUSTOMER_ID_COUNTER++);
		BankingDAOServicesImpl.customers.put(customer1.getCustomerId(), customer1);
		Customer customer2=new Customer("ggh788","anu", "sss", "phg.com", new Address(12364, "hy", "tg"), new Address(463, "gdk","tg"));
		customer2.setCustomerId(BankingUtility.CUSTOMER_ID_COUNTER++);
		BankingDAOServicesImpl.customers.put(customer2.getCustomerId(), customer2);
		Customer customer3=new Customer("ggh788","sam", "ggg", "pichuj.com", new Address(17354, "hd", "tg"), new Address(563, "gdk","tg"));
		customer3.setCustomerId(BankingUtility.CUSTOMER_ID_COUNTER++);	
		BankingDAOServicesImpl.customers.put(customer3.getCustomerId(), customer3);
		
		Account account1=new Account(120000,"savings" );
		account1.setAccountNo(BankingUtility.ACCOUNT_NUM_COUNTER);
		account1.setStatus("active");
		account1.setPinNumber(123);
		BankingDAOServicesImpl.customers.get(customer1.getAccounts().put((long) BankingUtility.ACCOUNT_NUM_COUNTER++, account1));
		Account account2=new Account(105000,"current");
		account2.setAccountNo(BankingUtility.ACCOUNT_NUM_COUNTER);
		account2.setStatus("active");
		account2.setPinNumber(124);
		BankingDAOServicesImpl.customers.get(customer2.getAccounts().put((long) BankingUtility.ACCOUNT_NUM_COUNTER++, account2));
		Account account3=new Account(1420000,"savings" );
		account3.setAccountNo(BankingUtility.ACCOUNT_NUM_COUNTER);
		account3.setStatus("active");
		account3.setPinNumber(125);
		BankingDAOServicesImpl.customers.get(customer3.getAccounts().put((long) BankingUtility.ACCOUNT_NUM_COUNTER++, account2));
		Transaction transaction1=new Transaction(10000, "withdrawl");
		transaction1.setTransactionId(BankingUtility.TRANSACTION_ID_COUNTER);
		BankingDAOServicesImpl.customers.get(customer1.getCustomerId()).getAccounts().get(account1.getAccountNo()).getTransactions().put(BankingUtility.TRANSACTION_ID_COUNTER++, transaction1);
		Transaction transaction2=new Transaction(2000, "withdrawl");
		transaction2.setTransactionId(BankingUtility.TRANSACTION_ID_COUNTER);
		BankingDAOServicesImpl.customers.get(customer2.getCustomerId()).getAccounts().get(account2.getAccountNo()).getTransactions().put(BankingUtility.TRANSACTION_ID_COUNTER++, transaction2);
		Transaction transaction3=new Transaction(3000, "withdrawl");
		transaction3.setTransactionId(BankingUtility.TRANSACTION_ID_COUNTER);
		BankingDAOServicesImpl.customers.get(customer3.getCustomerId()).getAccounts().get(account3.getAccountNo()).getTransactions().put(BankingUtility.TRANSACTION_ID_COUNTER++, transaction3);
	}
	//1
	@Test
	public void customerFound() throws CustomerNotFoundException, BankingServicesDownException{
		int actual=bankingservices.acceptCustomerDetails("asd", "asd", "asd", "asd", "asd", "asdf", 456, "asd", "asd", 456);
		assertEquals(114, actual);
	}
	@Test
	public void validCustomer() throws CustomerNotFoundException, BankingServicesDownException {
		Customer customer2=new Customer("ggh788","anu", "sss", "phg.com", new Address(12364, "hy", "tg"), new Address(463, "gdk","tg"));
		customer2.setCustomerId(112);
		BankingDAOServicesImpl.customers.put(customer2.getCustomerId(), customer2);
		Account account2=new Account(105000,"current");
		BankingDAOServicesImpl.customers.get(customer2.getAccounts().put((long) BankingUtility.ACCOUNT_NUM_COUNTER, account2));
		assertEquals(bankingservices.getCustomerDetails(112), customer2);
	}
	@Test(expected=CustomerNotFoundException.class)
	public void inValidCustomer() throws CustomerNotFoundException, BankingServicesDownException {
		Customer expectedcust=bankingservices.getCustomerDetails(118);
		Customer actualcust=new Customer("ggh788","anu", "sss", "phg.com", new Address(12364, "hy", "tg"), new Address(463, "gdk","tg"));
		assertEquals(expectedcust, actualcust);
	}
	//2
	@Test
	public void validAccountOpen() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, InvalidAmountException, InvalidAccountTypeException{
		long actual=bankingservices.openAccount(111, "savings", 120000);
		assertEquals(2003, actual);
	}
	@Test(expected=CustomerNotFoundException.class)
	public void inValidOpenAccount() throws AccountNotFoundException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, BankingServicesDownException{
		long actual=bankingservices.openAccount(118, "savings", 12212);
		assertEquals(2004, actual);
	}  
	@Test(expected=CustomerNotFoundException.class)
	public void inValidCustomerAccountOpen() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, InvalidAmountException, InvalidAccountTypeException{
		long actual=bankingservices.openAccount(118, "savings", 120000);
		assertEquals(2003, actual);
	}
	@Test(expected=InvalidAccountTypeException.class)
	public void inValidAccountTypeOpen() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, InvalidAmountException, InvalidAccountTypeException{
		bankingservices.openAccount(111, "lrrent", 120000);
		
	}
	@Test
	public void validInitBal() throws InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, BankingServicesDownException{
		bankingservices.openAccount(111, "savings", 1000);
	}
	@Test(expected=InvalidAmountException.class)
	public void inValidInitBal() throws InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, BankingServicesDownException{
		bankingservices.openAccount(111, "savings", 000);
	}
	//3
	@Test 
	public void validAmountForValidIdnAcntNo() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException{
		long actual=(long) bankingservices.depositAmount(111, 2000, 5000);
		assertEquals(125000, actual);
	}
	@Test(expected=InvalidAmountException.class)
	public void inValidAmountForValidIdnAcntNo() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException{
		long actual=(long) bankingservices.depositAmount(111, 2000, -5000);
		assertEquals(115000, actual);
	}
	
	@Test(expected=CustomerNotFoundException.class)
	public void validAmountForinValidIdnValidAcntNo() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException{
	bankingservices.depositAmount(119, 2000, 5000);
	}
	@Test(expected=AccountNotFoundException.class)
	public void validAmountForValidIdnInvalidAcntNo() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException{
		 bankingservices.depositAmount(111, 20500, 5000);
	}
	@Test(expected=AccountBlockedException.class)
	public void validAmountnIdForInvalidAcntStatus() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException{
		BankingDAOServicesImpl.customers.get(111).getAccounts().get(2000l).setStatus("blocked");
		bankingservices.depositAmount(111, 2000, 5000);
	}
	@Test
	public void validAmountnIdForvalidAcntStatus() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException{
		BankingDAOServicesImpl.customers.get(111).getAccounts().get(2000l).getStatus();
		bankingservices.depositAmount(111, 2000, 5000);
	}
	//4
	@Test
	public void allValidAmountDrawn() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException{
		long actual = (long) bankingservices.withdrawAmount(111, 2000, 5000, 123);
		assertEquals(115000,actual);
	}
	@Test(expected=CustomerNotFoundException.class)
	public void inValidCustomerAmountDrawn() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException{
		long actual = (long) bankingservices.withdrawAmount(118,2000, 5000, 123);
		assertEquals(115000,actual);
	}
	@Test(expected=InvalidPinNumberException.class)
	public void InValidPinAmountDrawn() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException{
		bankingservices.withdrawAmount(111, 2000, 2000000, 129);
	}     
	@Test(expected=AccountNotFoundException.class)
	public void InValidAcntAmountDrawn() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException{
		bankingservices.withdrawAmount(111, 20009, 2000000, 123);
	}   
	@Test(expected=InsufficientAmountException.class)
	public void InValidAmountDrawn() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException{
		long actual = (long) bankingservices.withdrawAmount(111, 2000, 2000000, 123);
		assertEquals(120000,actual);
	}
	@Test(expected=AccountBlockedException.class)
	public void InvalidAcntStatusAmountDrawn() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException, InsufficientAmountException, InvalidPinNumberException{
		BankingDAOServicesImpl.customers.get(111).getAccounts().get(2000l).setStatus("blocked");
		bankingservices.withdrawAmount(111, 2000, 5000, 123);
	}
	//5
	@Test
	public void validTranferFund() throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException, InvalidAmountException {
		boolean actual = bankingservices.fundTransfer(111, 2000, 112, 2001, 5000, 124);
		assertEquals(true, actual);
	}
	@Test(expected=InsufficientAmountException.class)
	public void inValidTranferFund() throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException, InvalidAmountException {
		boolean actual = bankingservices.fundTransfer(111, 2000, 112, 2001, 5000000, 124);
		assertEquals(true, actual);
	}
	@Test(expected=InvalidPinNumberException.class)
	public void inValidPin() throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException, InvalidAmountException {
		boolean actual = bankingservices.fundTransfer(111, 2000, 112, 2001, 5000, 1245);
		assertEquals(true, actual);
	}
	
	@After
	public void tearDownMockData(){
		BankingDAOServicesImpl.customers.clear();
		//PayrollDAOServicesImpl.associates.clear();
		BankingUtility.CUSTOMER_ID_COUNTER=111;
		BankingUtility.ACCOUNT_NUM_COUNTER=2000;
	}

	@AfterClass
	public static void tearDownTestEnv(){
		bankingservices=null;
	}
}

