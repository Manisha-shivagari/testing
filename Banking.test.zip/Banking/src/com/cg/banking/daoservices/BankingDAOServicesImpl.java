
package com.cg.banking.daoservices;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.utility.BankingUtility;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

public class BankingDAOServicesImpl implements BankingDAOServices {
	public static HashMap<Integer,Customer> customers = new HashMap<>();
	
	@Override
	public int insertCustomer(Customer customer) {
		customer.setCustomerId((BankingUtility.CUSTOMER_ID_COUNTER));
		//customer.setCustomerId(CUSTOMER_ID_COUNTER++);
		customers.put(customer.getCustomerId(),customer);
		return customer.getCustomerId();
	}
	@Override
	public long insertAccount(int customerId, Account account) {
		account.setAccountNo(BankingUtility.ACCOUNT_NUM_COUNTER);
		getCustomer(customerId).getAccounts().put(account.getAccountNo(), account);
		return account.getAccountNo();
	}
	@Override
	public boolean updateAccount(int customerId, Account account) {
		getCustomer(customerId).getAccounts().put(account.getAccountNo(), account);
		return false;
	}
	@Override
	public int generatePin(int customerId, Account account) {
		Random random=new Random();
		account.setPinNumber(random.nextInt(10000));
		getCustomer(customerId).getAccounts().put(account.getAccountNo(), account);
		return account.getPinNumber();

	}
	@Override
	public boolean insertTransaction(int customerId, long accountNo, Transaction transaction) {
		transaction.setTransactionId((BankingUtility.TRANSACTION_ID_COUNTER));
		getAccount(customerId, accountNo).getTransactions().put(transaction.getTransactionId(), transaction);
		return false;
	}
	@Override
	public boolean deleteCustomer(int customerId) {
		customers.remove(customerId);
		return true;
	}
	@Override
	public boolean deleteAccount(int customerId, long accountNo) {
		getCustomer(customerId).getAccounts().remove(accountNo);
		return true;
	}
	@Override
	public Customer getCustomer(int customerId) {
		return customers.get(customerId);

	}
	@Override
	public Account getAccount(int customerId, long accountNo) {
		return customers.get(customerId).getAccounts().get(accountNo);
	}
	@Override
	public List<Customer> getCustomers() {
		return new ArrayList<>(customers.values());
	}
	@Override
	public List<Account> getAccounts(int customerId) {
		return new ArrayList<>(customers.get(customerId).getAccounts().values());
	}
	@Override
	public List<Transaction> getTransactions(int customerId, long accountNo) {
		return new ArrayList<>(getAccount(customerId, accountNo).getTransactions().values());
	}














	/*@Override
	public int insertCustomer(Customer customer) {
		customer.setCustomerId(CUSTOMER_ID_COUNTER++);
		customerList[CUSTOMER_IDX_COUNTER++]=customer;
		return customer.getCustomerId();
	}

	@Override
	public long insertAccount(int customerId, Account account){
		account.setAccountNo(account_No_Generator);
		getCustomer(customerId).getAccount()[getCustomer(customerId).getAccount_idx_counter()]=account;
		getCustomer(customerId).setAccount_idx_counter(getCustomer(customerId).getAccount_idx_counter()+1);
		return getCustomer(customerId).getAccount()[getCustomer(customerId).getAccount_idx_counter()-1].getAccountNo();
	}

	@Override
	public boolean updateAccount(int customerId, Account account) {
		for(int j=0;j<getCustomer(customerId).getAccount().length;j++)
			if(getCustomer(customerId).getAccount()[j].getAccountNo()==account.getAccountNo()) {
				getCustomer(customerId).getAccount()[j]=account;
				return true;
			}
		return false;
	}
	@Override
	public int generatePin(int customerId, Account account) {
		Random rand = new Random();
		int num = rand.nextInt(9000) + 1000;
		return 0;
	}
	@Override
	public boolean insertTransaction(int customerId, long accountNo, Transaction transaction) {
		transaction.setTransactionId(TRANSACTION_ID_COUNTER++);

		//return transaction.getTransactionId();
		return false;
	}
	@Override
	public boolean deleteCustomer(int customerId) {
		for(int i=0;i<customerList.length;i++)
			if(customerList[i]!=null && customerId==customerList[i].getCustomerId()){
				customerList[i]=null;
				return true;
			}
		return false;

	}
	@Override
	public boolean deleteAccount(int customerId, long accountNo) {
		for(i=0;i<getCustomer(customerId).getAccount().length;i++)	
		if(getCustomer(customerId).getAccount()[i].getAccountNo()==accountNo){
		getCustomer(customerId).getAccount()[i]=null;
		return true;
	}
		return false;
	}
	@Override
	public Customer getCustomer(int customerId) {
		for(i=0;i<customerList.length;i++)
			if(customerList[i]!=null && customerId==customerList[i].getCustomerId()){
				return customerList[i];
			}
		return null;
	}
	@Override
	public Account getAccount(int customerId, long accountNo) {
		for(i=0;i<getCustomer(customerId).getAccount().length;i++)
			if(getCustomer(customerId).getAccount()[i].getAccountNo()==accountNo){
				return getCustomer(customerId).getAccount()[i];
			}
		return null;
	}
	@Override
	public Customer[] getCustomers() {

		return null;
	}
	@Override
	public Account[] getAccounts(int customerId) {

		return null;
	}
	@Override
	public Transaction[] getTransactions(int customerId, long accountNo) {

		return null;
	}*/



}
