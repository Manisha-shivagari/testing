package com.cg.banking.beans;

import java.util.HashMap;

public class Customer {
	private int customerId;
	private String firstName,lastName,emailId,dateOfBirth, panCard;
	private Address homeAddress,localAddress;
	private HashMap<Long,Account> accounts = new HashMap<>();
	public Customer(){}

	public Customer(String panCard, String firstName, String lastName, String emailId, Address homeAddress,
			Address localAddress) {
		super();
		this.panCard = panCard;
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailId = emailId;
		this.homeAddress = homeAddress;
		this.localAddress = localAddress;
	}

	
	public Customer(int customerId,String panCard, String firstName, String lastName, String emailId,
			String dateOfBirth, Address homeAddress, Address localAddress, HashMap<Long, Account> accounts) {
		super();
		this.customerId = customerId;
		this.panCard = panCard;
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailId = emailId;
		this.dateOfBirth = dateOfBirth;
		this.homeAddress = homeAddress;
		this.localAddress = localAddress;
		this.accounts = accounts;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}


	public String getPanCard() {
		return panCard;
	}

	public void setPanCard(String panCard) {
		this.panCard = panCard;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public Address getHomeAddress() {
		return homeAddress;
	}

	public void setHomeAddress(Address homeAddress) {
		this.homeAddress = homeAddress;
	}

	public Address getLocalAddress() {
		return localAddress;
	}

	public void setLocalAddress(Address localAddress) {
		this.localAddress = localAddress;
	}

	public HashMap<Long, Account> getAccounts() {
		return accounts;
	}

	public void setAccounts(HashMap<Long, Account> accounts) {
		this.accounts = accounts;
	}

	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
	//	result = prime * result + ((accounts == null) ? 0 : accounts.hashCode());
		result = prime * result + customerId;
		result = prime * result + ((dateOfBirth == null) ? 0 : dateOfBirth.hashCode());
		result = prime * result + ((emailId == null) ? 0 : emailId.hashCode());
		result = prime * result + ((firstName == null) ? 0 : firstName.hashCode());
		result = prime * result + ((homeAddress == null) ? 0 : homeAddress.hashCode());
		result = prime * result + ((lastName == null) ? 0 : lastName.hashCode());
		result = prime * result + ((localAddress == null) ? 0 : localAddress.hashCode());
		result = prime * result + ((panCard == null) ? 0 : panCard.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Customer other = (Customer) obj;
	//	if (accounts == null) {
	//		if (other.accounts != null)
	//			return false;
	//	} else if (!accounts.equals(other.accounts))
	//		return false;
		if (customerId != other.customerId)
			return false;
		if (dateOfBirth == null) {
			if (other.dateOfBirth != null)
				return false;
		} else if (!dateOfBirth.equals(other.dateOfBirth))
			return false;
		if (emailId == null) {
			if (other.emailId != null)
				return false;
		} else if (!emailId.equals(other.emailId))
			return false;
		if (firstName == null) {
			if (other.firstName != null)
				return false;
		} else if (!firstName.equals(other.firstName))
			return false;
		if (homeAddress == null) {
			if (other.homeAddress != null)
				return false;
		} else if (!homeAddress.equals(other.homeAddress))
			return false;
		if (lastName == null) {
			if (other.lastName != null)
				return false;
		} else if (!lastName.equals(other.lastName))
			return false;
		if (localAddress == null) {
			if (other.localAddress != null)
				return false;
		} else if (!localAddress.equals(other.localAddress))
			return false;

		if (panCard == null) {
			if (other.panCard != null)
				return false;
		} else if (!panCard.equals(other.panCard))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", emailId=" + emailId + ", dateOfBirth=" + dateOfBirth + ", panCard=" + panCard + ", homeAddress="
				+ homeAddress + ", localAddress=" + localAddress + ", accounts=" + accounts + "]";
	}



}
//accountList[ACCOUNT_IDX_COUNTER++]=account;